export const COLORS = {
  red: '#F42619',
  red2: '#F76153',
  white: '#FFFFFF',
  gray: '#C6C0C0',
  gray2: '#CFCFCF',
  black: '#000000',
  black2: '#140D0D',
};
