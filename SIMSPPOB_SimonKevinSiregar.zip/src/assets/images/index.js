import Banner1 from './Banner1.png';
import Banner2 from './Banner2.png';
import Banner3 from './Banner3.png';
import Banner4 from './Banner4.png';
import Banner5 from './Banner5.png';
import Bgsaldo from './Bgsaldo.png';
import Logo from './Logo.png';
import Profile2 from './Profile2.png';

export const Images = {
  Banner1,
  Banner2,
  Banner3,
  Banner4,
  Banner5,
  Bgsaldo,
  Logo,
  Profile2,
};
