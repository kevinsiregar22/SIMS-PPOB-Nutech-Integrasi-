export const dummyBanner = [
  {
    banner_name: 'Banner 1',
    banner_image:
      'https://minio.nutech-integrasi.app/take-home-test/banner/Banner-1.png',
    description: 'Lerem Ipsum Dolor sit amet',
  },
  {
    banner_name: 'Banner 2',
    banner_image:
      'https://minio.nutech-integrasi.app/take-home-test/banner/Banner-2.png',
    description: 'Lerem Ipsum Dolor sit amet',
  },
  {
    banner_name: 'Banner 3',
    banner_image:
      'https://minio.nutech-integrasi.app/take-home-test/banner/Banner-3.png',
    description: 'Lerem Ipsum Dolor sit amet',
  },
  {
    banner_name: 'Banner 4',
    banner_image:
      'https://minio.nutech-integrasi.app/take-home-test/banner/Banner-4.png',
    description: 'Lerem Ipsum Dolor sit amet',
  },
  {
    banner_name: 'Banner 5',
    banner_image:
      'https://minio.nutech-integrasi.app/take-home-test/banner/Banner-5.png',
    description: 'Lerem Ipsum Dolor sit amet',
  },
];
