import {View, Text} from 'react-native';
import React from 'react';

const HistoryScreen = () => {
  return (
    <View>
      <Text>HistoryScreen</Text>
    </View>
  );
};

export default HistoryScreen;
